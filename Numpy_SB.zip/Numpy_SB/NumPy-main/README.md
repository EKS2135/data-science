# NumPy
Here you will get the notes of Numpy , coded in JupyterNotebook and hence followed Unschool lecture.
