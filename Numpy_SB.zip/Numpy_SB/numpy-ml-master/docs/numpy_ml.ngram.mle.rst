``MLENGram``
------------

.. autoclass:: numpy_ml.ngram.MLENGram
        :members:
	:undoc-members:
	:inherited-members:
