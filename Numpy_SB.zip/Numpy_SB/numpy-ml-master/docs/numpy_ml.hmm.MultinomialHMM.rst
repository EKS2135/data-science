``MultinomialHMM``
------------------

.. autoclass:: numpy_ml.hmm.MultinomialHMM
	:members:
	:undoc-members:
	:inherited-members:
