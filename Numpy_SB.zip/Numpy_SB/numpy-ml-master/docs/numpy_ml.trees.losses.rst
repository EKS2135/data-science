#########################
Losses (``trees.losses``)
#########################

.. automodule:: numpy_ml.trees.losses
	:members:
	:undoc-members:
	:inherited-members:
	:show-inheritance:
