################
``DecisionTree``
################

.. autoclass:: numpy_ml.trees.DecisionTree
	:members:
	:undoc-members:
	:inherited-members:
