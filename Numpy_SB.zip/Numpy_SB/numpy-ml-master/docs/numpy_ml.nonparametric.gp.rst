``GPRegression``
#################

.. autoclass:: numpy_ml.nonparametric.GPRegression
	:members:
	:undoc-members:
	:inherited-members:
