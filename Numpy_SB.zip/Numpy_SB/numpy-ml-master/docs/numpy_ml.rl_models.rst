Reinforcement learning
######################

.. toctree::
   :maxdepth: 3

   numpy_ml.rl_models.agents

   numpy_ml.rl_models.trainer

   numpy_ml.rl_models.rl_utils
